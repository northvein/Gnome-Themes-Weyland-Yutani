#!/usr/bin/env bash
# ============================================================
# WEYLAND-YUTANI CORPORATION
# Theme Installation Script v2.179
# "Building Better Worlds"
# ============================================================

set -e

THEME_NAME="Weyland-Yutani"
THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "  ██╗    ██╗███████╗██╗   ██╗██╗      █████╗ ███╗   ██╗██████╗ "
echo "  ██║    ██║██╔════╝╚██╗ ██╔╝██║     ██╔══██╗████╗  ██║██╔══██╗"
echo "  ██║ █╗ ██║█████╗   ╚████╔╝ ██║     ███████║██╔██╗ ██║██║  ██║"
echo "  ██║███╗██║██╔══╝    ╚██╔╝  ██║     ██╔══██║██║╚██╗██║██║  ██║"
echo "  ╚███╔███╔╝███████╗   ██║   ███████╗██║  ██║██║ ╚████║██████╔╝"
echo "   ╚══╝╚══╝ ╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ "
echo ""
echo "  ██╗   ██╗██╗   ██╗████████╗ █████╗ ███╗   ██╗██╗"
echo "  ╚██╗ ██╔╝██║   ██║╚══██╔══╝██╔══██╗████╗  ██║██║"
echo "   ╚████╔╝ ██║   ██║   ██║   ███████║██╔██╗ ██║██║"
echo "    ╚██╔╝  ██║   ██║   ██║   ██╔══██║██║╚██╗██║██║"
echo "     ██║   ╚██████╔╝   ██║   ██║  ██║██║ ╚████║██║"
echo "     ╚═╝    ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝"
echo ""
echo "  CORPORATION — Building Better Worlds"
echo "  Theme Installer — Clearance: EXECUTIVE"
echo "  =================================================="
echo ""

# ---- GTK THEME ----
echo "  [1/5] Installing GTK theme..."
GTK_THEME_PATH="$HOME/.themes/$THEME_NAME"
mkdir -p "$GTK_THEME_PATH"
cp -r "$THEME_DIR/gtk-3.0" "$GTK_THEME_PATH/"
cp -r "$THEME_DIR/gtk-4.0" "$GTK_THEME_PATH/"
cp "$THEME_DIR/index.theme" "$GTK_THEME_PATH/"
echo "        ✓ GTK theme installed to ~/.themes/$THEME_NAME"

# ---- GNOME SHELL THEME ----
echo "  [2/5] Installing GNOME Shell theme..."
SHELL_THEME_PATH="$HOME/.themes/$THEME_NAME/gnome-shell"
mkdir -p "$SHELL_THEME_PATH"
cp -r "$THEME_DIR/gnome-shell/." "$SHELL_THEME_PATH/"
echo "        ✓ Shell theme installed"

# ---- APPLY GTK THEME ----
echo "  [3/5] Applying GTK theme via gsettings..."
if command -v gsettings &>/dev/null; then
  gsettings set org.gnome.desktop.interface gtk-theme "$THEME_NAME" 2>/dev/null && \
    echo "        ✓ GTK theme applied" || echo "        ⚠ Could not apply automatically — see manual steps below"
  gsettings set org.gnome.desktop.interface color-scheme "prefer-dark" 2>/dev/null && \
    echo "        ✓ Dark mode enabled" || true
else
  echo "        ⚠ gsettings not found — apply manually via GNOME Tweaks"
fi

# ---- APPLY SHELL THEME ----
echo "  [4/5] Applying GNOME Shell theme..."
if command -v gsettings &>/dev/null; then
  gsettings set org.gnome.shell.extensions.user-theme name "$THEME_NAME" 2>/dev/null && \
    echo "        ✓ Shell theme applied" || \
    echo "        ⚠ User Themes extension required — install from extensions.gnome.org"
fi

# ---- TERMINAL COLOR SCHEME ----
echo "  [5/5] Installing terminal color scheme..."
if command -v dconf &>/dev/null && command -v gsettings &>/dev/null; then

  TERMINAL_PROFILE=$(gsettings get org.gnome.Terminal.ProfilesList default 2>/dev/null | tr -d "'")

  if [ -n "$TERMINAL_PROFILE" ]; then
    BASE="org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$TERMINAL_PROFILE/"

    dconf write "${BASE}use-theme-colors" "false"
    dconf write "${BASE}background-color" "'#080A08'"
    dconf write "${BASE}foreground-color" "'#C8920A'"
    dconf write "${BASE}cursor-color" "'#E8AA18'"
    dconf write "${BASE}cursor-colors-set" "true"
    dconf write "${BASE}use-transparent-background" "false"
    dconf write "${BASE}palette" "['#1A1F1A', '#6B1414', '#2D5028', '#8A6208', '#1A3A5C', '#3A1A4A', '#1A4A4A', '#C8B896', '#2A352A', '#C0392B', '#39FF14', '#E8AA18', '#2A5A8C', '#7B2FA8', '#1ABCBC', '#E8D8B4']"
    dconf write "${BASE}font" "'Courier New 12'"
    dconf write "${BASE}use-system-font" "false"
    dconf write "${BASE}scrollbar-policy" "'never'"
    dconf write "${BASE}visible-name" "'Weyland-Yutani'"

    echo "        ✓ Terminal colors applied to default profile"
  else
    echo "        ⚠ No GNOME Terminal profile found — colors in assets/terminal-colors.ini"
  fi
else
  echo "        ⚠ dconf not available — apply terminal colors manually"
fi

# ---- RECOMMENDED EXTENSIONS ----
echo ""
echo "  =================================================="
echo "  INSTALLATION COMPLETE"
echo "  =================================================="
echo ""
echo "  RECOMMENDED GNOME EXTENSIONS:"
echo "  • User Themes (required for Shell theme)"
echo "    → extensions.gnome.org/extension/19/user-themes/"
echo ""
echo "  • Dash to Panel (for full taskbar experience)"
echo "    → extensions.gnome.org/extension/1160/dash-to-panel/"
echo ""
echo "  MANUAL STEPS (if auto-apply failed):"
echo "  1. Install 'GNOME Tweaks': sudo apt install gnome-tweaks"
echo "  2. Open Tweaks > Appearance"
echo "  3. Set Applications theme to: $THEME_NAME"
echo "  4. Set Shell theme to: $THEME_NAME (requires User Themes ext.)"
echo ""
echo "  FONT RECOMMENDATION:"
echo "  • Install 'Courier Prime' or 'Share Tech Mono' for optimal look"
echo "    sudo apt install fonts-courier-prime 2>/dev/null || true"
echo ""
echo "  ██████╗ ██╗   ██╗██╗██╗     ██████╗ ██╗███╗   ██╗ ██████╗"
echo "  ██╔══██╗██║   ██║██║██║     ██╔══██╗██║████╗  ██║██╔════╝"
echo "  ██████╔╝██║   ██║██║██║     ██║  ██║██║██╔██╗ ██║██║  ███╗"
echo "  ██╔══██╗██║   ██║██║██║     ██║  ██║██║██║╚██╗██║██║   ██║"
echo "  ██████╔╝╚██████╔╝██║███████╗██████╔╝██║██║ ╚████║╚██████╔╝"
echo "  ╚═════╝  ╚═════╝ ╚═╝╚══════╝╚═════╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝"
echo "  ██████╗ ███████╗████████╗████████╗███████╗██████╗"
echo "  ██╔══██╗██╔════╝╚══██╔══╝╚══██╔══╝██╔════╝██╔══██╗"
echo "  ██████╔╝█████╗     ██║      ██║   █████╗  ██████╔╝"
echo "  ██╔══██╗██╔══╝     ██║      ██║   ██╔══╝  ██╔══██╗"
echo "  ██████╔╝███████╗   ██║      ██║   ███████╗██║  ██║"
echo "  ╚═════╝ ╚══════╝   ╚═╝      ╚═╝   ╚══════╝╚═╝  ╚═╝"
echo "  ██╗    ██╗ ██████╗ ██████╗ ██╗     ██████╗  ███████╗"
echo "  ██║    ██║██╔═══██╗██╔══██╗██║     ██╔══██╗██╔════╝"
echo "  ██║ █╗ ██║██║   ██║██████╔╝██║     ██║  ██║███████╗"
echo "  ██║███╗██║██║   ██║██╔══██╗██║     ██║  ██║╚════██║"
echo "  ╚███╔███╔╝╚██████╔╝██║  ██║███████╗██████╔╝███████║"
echo "   ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝ ╚══════╝"
echo ""
